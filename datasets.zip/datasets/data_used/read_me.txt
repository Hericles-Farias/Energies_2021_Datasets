pv_ufsm.CSV was used as the per unity loadshape for the real photovoltaic output in the simulation.
pv_ufsm_forec.CSV was used as the forecast values for the PV output.
wt is the white tariff costs used in the simulation.
