cl0 - 8 time steps [4 horas]
cl1 - 6 time steps [3 horas]
cl2 - 6 time steps [3 horas]
cl3 - 6 time steps [3 horas]
cl4 - 8 time steps [4 horas]
cl5 - 8 time steps [4 horas]
cl6 - 6 time steps [3 horas]
 
FC=1 TS
NC=2 TS
SC=3 TS

TS tem .5 H ou 30 min
