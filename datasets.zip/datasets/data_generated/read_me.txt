clusters_1 contains the users requests for every cluster in the simulation.
epso_results contains the final results for each case.
milp_initial_solution contains the initial solution provided by the milp approach.